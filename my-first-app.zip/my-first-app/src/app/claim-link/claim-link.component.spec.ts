import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClaimLinkComponent } from './claim-link.component';

describe('ClaimLinkComponent', () => {
  let component: ClaimLinkComponent;
  let fixture: ComponentFixture<ClaimLinkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClaimLinkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClaimLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
