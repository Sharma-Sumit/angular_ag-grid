import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claim-link',
  templateUrl: './claim-link.component.html',
  styleUrls: ['./claim-link.component.css']
})
export class ClaimLinkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
