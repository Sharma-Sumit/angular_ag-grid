import {Component, OnInit, ViewChild} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'ag-grid-enterprise';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import {AgGridAngular} from 'ag-grid-angular';
import {ClaimLinkComponent} from './claim-link/claim-link.component';
import {ButtonRendererComponent} from './renderer/button-renderer.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ]
})
export class AppComponent implements OnInit{
  @ViewChild('agGrid') agGrid: AgGridAngular;
  public gridApi;
  public gridColumnApi;

  public columnDefs;
  public defaultColDef;
  public sideBar;
  public rowData;
  public frameworkComponents;
  rowDataClicked1 = {};
  constructor(private http: HttpClient) {
    this.frameworkComponents = {
      claimLinkCellRenderer: ClaimLinkComponent,
      buttonRenderer: ButtonRendererComponent,
    };
    this.columnDefs = [
      {
        headerName: 'Athlete',
        children: [
          {
            field: 'athlete',
            filter: 'agTextColumnFilter',
            minWidth: 200, checkboxSelection: true
          },
          { field: 'age' },
          {
            field: 'country',
            minWidth: 200,
          },
        ],
      },
      {
        headerName: 'Competition',
        children: [
          { field: 'year',
            filter: 'agTextColumnFilter'},
          {
            field: 'date',
            minWidth: 180,
          },
        ],
      },
      {
        field: 'sport',
        minWidth: 200,
      },
      {
        headerName: 'Medals',
        children: [
          { field: 'gold' },
          { field: 'silver' },
          { field: 'bronze' },
          { field: 'total' },
        ],
      },
      {
        headerName: 'claim Exception',
        field: 'claim',
        cellRenderer: 'buttonRenderer',
        cellRendererParams: {
          onClick: this.onBtnClick1.bind(this),
          label: 'claim'
        }
      }
    ];
    this.defaultColDef = {
      flex: 1,
      minWidth: 100,
      enableValue: true,
      enableRowGroup: true,
      enablePivot: true,
      sortable: true,
      filter: true,
      floatingFilter: true
    };

    /*this.columnDefs = [
      {headerName: 'Make', field: 'make', sortable: true, filter: true},
      {headerName: 'Model', field: 'model', sortable: true, filter: true},
      {headerName: 'Price', field: 'price', sortable: true, filter: true}
    ];
    this.defaultColDef = {
      flex: 1,
      minWidth: 100,
      enableValue: true,
      enableRowGroup: true,
      enablePivot: true,
      sortable: true,
      filter: true,
    };*/

    /*this.rowData = [
      { make: 'Toyota', model: 'Celica', price: 35000 },
      { make: 'Ford', model: 'Mondeo', price: 32000 },
      { make: 'Porsche', model: 'Boxter', price: 72000 }
    ];*/
    this.sideBar = {
      toolPanels: [
        {
          id: 'columns',
          labelDefault: 'Columns',
          labelKey: 'columns',
          iconKey: 'columns',
          toolPanel: 'agColumnsToolPanel',

        },
      ],
      position: 'left',
      defaultToolPanel: 'columns',
    };
  }

  ngOnInit() {
    // this.rowData = this.http.get('https://raw.githubusercontent.com/ag-grid/ag-grid/master/grid-packages/ag-grid-docs/src/sample-data/smallRowData.json');
  }
  onBtnClick1(e) {
    this.rowDataClicked1 = e.rowData;
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    console.log(this.rowData);
    this.http
      .get(
        // 'https://raw.githubusercontent.com/ag-grid/ag-grid/master/grid-packages/ag-grid-docs/src/olympicWinners.json'
        '../assets/sampleJson.json'
      )
      .subscribe(data => {

        this.rowData = data;
        console.log(this.rowData);
      });
  }

  getSelectedRows() {
    console.log(this.agGrid.columnApi);
    console.log(this.agGrid.api.getSelectedNodes());
    const selectedNodes = this.agGrid.api.getSelectedNodes();
    const selectedData = selectedNodes.map( node => node.data );
    console.log(selectedData);
    const selectedDataStringPresentation = selectedData.map( node => node.athlete + ' ' + node.age).join(', ');
    alert(`Selected nodes: ${selectedDataStringPresentation}`);
  }

  RefreshAll() {
    const params = {
      force: true,
      suppressFlash: true,
    };
    this.gridApi.refreshCells(params);
  }
}
