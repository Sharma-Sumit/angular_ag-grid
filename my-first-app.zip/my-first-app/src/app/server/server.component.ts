import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-server',
  templateUrl: './server.component.html',
  styleUrls: ['./server.component.css']
})
export class ServerComponent implements OnInit {
  serverID = 10;
  serverName = 'localhostNode';
  serverStatus = 'OffLine';
  enableAddServer = false;
  addServerStatus = 'No server was added';
  displayServer = false;
 // moodLighting = Math.random() > 0.5 ? 'blue' : 'green' ;
  moodLighting: string;
  ngOnInit(): void {

  }
  getServerName(){
    return this.serverName;
  }
  constructor() {
    setTimeout(() => {
      this.enableAddServer = true;
    }, 3000);
    this.moodLighting = Math.random() > 0.5 ? 'blue' : 'green' ;
  }
  onClickAddServer(){
    this.addServerStatus = 'Server was added';
    this.displayServer = true;
  }
  onServerNameInput(event: any){
    this.serverName = event.target.value;
  }
}
