import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { ServerComponent } from './server/server.component';
import {AgGridModule} from 'ag-grid-angular';
import {HttpClientModule} from '@angular/common/http';
import 'ag-grid-enterprise';
import { ClaimLinkComponent } from './claim-link/claim-link.component';
import {ButtonRendererComponent} from './renderer/button-renderer.component';
@NgModule({
  declarations: [
    AppComponent,
    ServerComponent,
    ClaimLinkComponent,
    ButtonRendererComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AgGridModule.withComponents([ButtonRendererComponent]), HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
